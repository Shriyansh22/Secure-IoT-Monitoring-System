/*
 * ============================================================
 * Secure IoT Monitoring System — ESP8266 Firmware
 * ============================================================
 * Author  : Shriyanshu Kumar Chaudhary
 * Team    : Harshit Gupta, Anjali Raj, Shivanand, Anupam Chaurasiya
 * College : Faculty of Technology, University of Delhi
 * Supervisor: Mr. Sunil Kumar
 * Session : 2025–2026
 *
 * Hardware:
 *   - NodeMCU ESP8266
 *   - DHT11 → D4 (GPIO2)
 *   - MQ-2  → A0
 *   - LED   → D2 (GPIO4)
 *   - Buzzer→ D1 (GPIO5)
 * ============================================================
 */

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include <base64.h>

// ---- WiFi Credentials ----
const char* SSID     = "YOUR_WIFI_SSID";
const char* PASSWORD = "YOUR_WIFI_PASSWORD";

// ---- Server ----
const char* SERVER_URL = "http://192.168.1.100:5000/data";

// ---- XOR Encryption Key ----
const String XOR_KEY = "SecureKey2025";

// ---- Pin Definitions ----
#define DHT_PIN     D4
#define DHT_TYPE    DHT11
#define MQ2_PIN     A0
#define LED_PIN     D2
#define BUZZER_PIN  D1

// ---- Thresholds ----
#define GAS_THRESHOLD   200   // ADC value (0–1023)
#define TEMP_THRESHOLD  40.0  // Celsius
#define HUM_THRESHOLD   85.0  // Percent

// ---- Sampling ----
#define SAMPLE_INTERVAL 5000  // ms

DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient wifiClient;
unsigned long lastSample = 0;

// ============================================================
// XOR Encrypt + Base64 Encode
// ============================================================
String xorEncrypt(String data, String key) {
  String encrypted = "";
  int keyLen = key.length();
  for (int i = 0; i < data.length(); i++) {
    encrypted += (char)(data[i] ^ key[i % keyLen]);
  }
  return base64::encode(encrypted);
}

// ============================================================
// Blink LED + Buzz
// ============================================================
void alertOnce(int ledPin, int buzzPin, int freq, int dur) {
  tone(buzzPin, freq, dur);
  digitalWrite(ledPin, HIGH);
  delay(dur);
  noTone(buzzPin);
  digitalWrite(ledPin, LOW);
}

void triggerAlert() {
  for (int i = 0; i < 3; i++) {
    alertOnce(LED_PIN, BUZZER_PIN, 3000, 200);
    delay(100);
  }
}

// ============================================================
// Setup
// ============================================================
void setup() {
  Serial.begin(115200);
  dht.begin();

  pinMode(LED_PIN,    OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(LED_PIN,    LOW);
  digitalWrite(BUZZER_PIN, LOW);

  // Connect WiFi
  Serial.print("Connecting to WiFi");
  WiFi.begin(SSID, PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected! IP: " + WiFi.localIP().toString());
  alertOnce(LED_PIN, BUZZER_PIN, 4000, 300); // startup beep
}

// ============================================================
// Main Loop
// ============================================================
void loop() {
  if (millis() - lastSample < SAMPLE_INTERVAL) return;
  lastSample = millis();

  // ---- Read Sensors ----
  float temperature = dht.readTemperature();
  float humidity    = dht.readHumidity();
  int   gas         = analogRead(MQ2_PIN);

  // Validate DHT readings
  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("[WARN] DHT11 read failed, skipping.");
    return;
  }

  Serial.printf("[READ] Temp=%.1f°C  Hum=%.1f%%  Gas=%d\n",
                temperature, humidity, gas);

  // ---- Build JSON Payload ----
  StaticJsonDocument<128> doc;
  doc["temperature"] = String(temperature, 1);
  doc["humidity"]    = String(humidity,    1);
  doc["gas"]         = gas;

  String jsonStr;
  serializeJson(doc, jsonStr);

  // ---- Encrypt ----
  String encrypted = xorEncrypt(jsonStr, XOR_KEY);
  Serial.println("[ENC] " + encrypted);

  // ---- HTTP POST ----
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(wifiClient, SERVER_URL);
    http.addHeader("Content-Type", "application/json");

    StaticJsonDocument<200> payload;
    payload["data"] = encrypted;
    String body;
    serializeJson(payload, body);

    int code = http.POST(body);
    Serial.printf("[HTTP] Response: %d\n", code);
    http.end();
  } else {
    Serial.println("[ERR] WiFi disconnected.");
  }

  // ---- Local Alerts ----
  bool hazard = (gas > GAS_THRESHOLD) ||
                (temperature > TEMP_THRESHOLD) ||
                (humidity > HUM_THRESHOLD);

  if (hazard) {
    Serial.println("[ALERT] Hazardous condition detected!");
    triggerAlert();
  }
}
