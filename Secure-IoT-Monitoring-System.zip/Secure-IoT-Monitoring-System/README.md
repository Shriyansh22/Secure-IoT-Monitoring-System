# 🔒 Secure IoT Monitoring System

![Platform](https://img.shields.io/badge/Platform-ESP8266-blue)
![Language](https://img.shields.io/badge/Language-Python%20%7C%20C%2B%2B%20%7C%20JavaScript-green)
![Framework](https://img.shields.io/badge/Framework-Flask-red)
![Status](https://img.shields.io/badge/Status-Completed-brightgreen)

> A secure, real-time IoT environmental monitoring system using ESP8266, Flask, and a live web dashboard with XOR-based encryption.

**Team:** Shriyanshu Kumar Chaudhary, Harshit Gupta, Anjali Raj, Shivanand, Anupam Chaurasiya  
**Supervisor:** Mr. Sunil Kumar  
**Institution:** Faculty of Technology, University of Delhi | B.Tech ECE (2025–26)

---

## 📌 Features

- ✅ Real-time temperature, humidity & gas monitoring (DHT11 + MQ-2)
- ✅ XOR + Base64 encrypted wireless data transmission
- ✅ Flask backend — decrypt, validate, log, and serve data
- ✅ Live dark-themed web dashboard with Chart.js graphs (2s auto-refresh)
- ✅ Multi-layer alert system: LED + Buzzer + dashboard notification
- ✅ CSV data logging with timestamped entries
- ✅ 100% packet transmission reliability | <2ms encryption latency

---

## 🏗️ System Architecture

```
DHT11 + MQ-2
     ↓
ESP8266 NodeMCU
  → XOR Encrypt + Base64
  → HTTP POST (Wi-Fi)
     ↓
Flask Backend (Python)
  → Decrypt + Validate + CSV Log
     ↓
Web Dashboard (HTML + Chart.js)
  → Live graphs, alerts, readings
```

---

## 🔌 Hardware Setup

| Component     | Pin         |
|---------------|-------------|
| DHT11         | D4 (GPIO2)  |
| MQ-2 Gas      | A0          |
| LED Indicator | D2 (GPIO4)  |
| Buzzer        | D1 (GPIO5)  |

---

## 📁 Project Structure

```
Secure-IoT-Monitoring-System/
├── arduino/
│   └── iot_monitor.ino       # ESP8266 firmware
├── backend/
│   ├── app.py                # Flask server
│   ├── requirements.txt
│   └── templates/
│       └── index.html        # Dashboard UI
└── README.md
```

---

## 🚀 Getting Started

### 1. ESP8266 Firmware
1. Open `arduino/iot_monitor.ino` in Arduino IDE
2. Install libraries: `ESP8266WiFi`, `DHT sensor library`, `ArduinoJson`, `base64`
3. Set your WiFi credentials and server IP in the sketch
4. Flash to ESP8266 NodeMCU

### 2. Flask Backend
```bash
cd backend
pip install -r requirements.txt
python app.py
```
Open `http://localhost:5000` in your browser.

---

## 📊 Performance Results

| Module            | Parameter               | Result          |
|-------------------|-------------------------|-----------------|
| Sensor Layer      | Sampling Frequency      | Every 5 seconds |
| ESP8266 Firmware  | Encryption Delay        | < 2 ms          |
| Network Layer     | Transmission Reliability| 0% Loss         |
| Backend Server    | Packet Decryption Time  | < 1.5 ms        |
| Dashboard         | Auto-Refresh Frequency  | 2 seconds       |
| Alert System      | Response Time           | Instant         |

---

## 🔐 Security

- Data encrypted using XOR cipher + Base64 encoding before transmission
- Prevents interception of raw sensor values over Wi-Fi
- Local-only architecture — no cloud dependency for privacy

---

## 📜 License

MIT License — free to use and modify with attribution.
