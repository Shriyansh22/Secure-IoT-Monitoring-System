from cryptography.fernet import Fernet # type: ignore

# Generate key only once, then save it
def create_key():
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)
    print("Key generated and saved!")

# Load key
def load_key():
    return open("secret.key", "rb").read()

# Encrypt data
def encrypt(data):
    key = load_key()
    f = Fernet(key)
    return f.encrypt(data.encode())

# Decrypt data
def decrypt(token):
    key = load_key()
    f = Fernet(key)
    return f.decrypt(token).decode()

if __name__ == "__main__":
    create_key()
