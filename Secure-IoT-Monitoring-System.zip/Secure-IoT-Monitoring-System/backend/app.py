"""
============================================================
Secure IoT Monitoring System — Flask Backend Server
============================================================
Author  : Shriyanshu Kumar Chaudhary
Team    : Harshit Gupta, Anjali Raj, Shivanand, Anupam Chaurasiya
College : Faculty of Technology, University of Delhi
Supervisor: Mr. Sunil Kumar
============================================================
Run:
    pip install flask
    python app.py
Then open: http://localhost:5000
============================================================
"""

from flask import Flask, request, jsonify, render_template
import base64
import json
import csv
import os
from datetime import datetime

app = Flask(__name__)

# ---- Config ----
XOR_KEY       = "SecureKey2025"
GAS_THRESHOLD = 200
CSV_FILE      = "sensor_log.csv"

# ---- In-memory storage for dashboard ----
latest_data = {"temperature": "--", "humidity": "--", "gas": "--", "timestamp": "--"}
history     = []   # last 50 readings

# ============================================================
# XOR Decrypt + Base64 Decode
# ============================================================
def xor_decrypt(encoded: str, key: str) -> str:
    try:
        decoded = base64.b64decode(encoded).decode("latin-1")
        result  = ""
        key_len = len(key)
        for i, ch in enumerate(decoded):
            result += chr(ord(ch) ^ ord(key[i % key_len]))
        return result
    except Exception as e:
        raise ValueError(f"Decryption failed: {e}")

# ============================================================
# CSV Logger
# ============================================================
def log_to_csv(temp, hum, gas):
    file_exists = os.path.isfile(CSV_FILE)
    with open(CSV_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Timestamp", "Temperature(C)", "Humidity(%)", "Gas(ADC)"])
        writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), temp, hum, gas])

# ============================================================
# Routes
# ============================================================

@app.route("/")
def index():
    return render_template("index.html", threshold=GAS_THRESHOLD)


@app.route("/data", methods=["POST"])
def receive_data():
    global latest_data, history
    try:
        body    = request.get_json(force=True)
        enc     = body.get("data", "")
        raw     = xor_decrypt(enc, XOR_KEY)
        payload = json.loads(raw)

        temp = payload.get("temperature", "N/A")
        hum  = payload.get("humidity",    "N/A")
        gas  = int(payload.get("gas",     0))
        ts   = datetime.now().strftime("%H:%M:%S")

        print(f"[OK] T={temp}°C  H={hum}%  Gas={gas}  @{ts}")

        # Update latest
        latest_data = {"temperature": temp, "humidity": hum,
                       "gas": gas, "timestamp": ts}

        # Update history (keep last 50)
        history.append({"time": ts, "temperature": float(temp),
                         "humidity": float(hum), "gas": gas})
        if len(history) > 50:
            history.pop(0)

        # Log to CSV
        log_to_csv(temp, hum, gas)

        # Alert check
        alert = gas > GAS_THRESHOLD
        if alert:
            print(f"[ALERT] Gas level {gas} exceeded threshold {GAS_THRESHOLD}!")

        return jsonify({"status": "ok", "alert": alert}), 200

    except Exception as e:
        print(f"[ERR] {e}")
        return jsonify({"status": "error", "message": str(e)}), 400


@app.route("/latest")
def get_latest():
    return jsonify(latest_data)


@app.route("/history")
def get_history():
    return jsonify(history)


@app.route("/status")
def status():
    return jsonify({
        "server":    "running",
        "readings":  len(history),
        "threshold": GAS_THRESHOLD,
        "timestamp": datetime.now().isoformat()
    })


# ============================================================
if __name__ == "__main__":
    print("=" * 50)
    print("  Secure IoT Monitoring System — Backend")
    print("  http://localhost:5000")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=True)
