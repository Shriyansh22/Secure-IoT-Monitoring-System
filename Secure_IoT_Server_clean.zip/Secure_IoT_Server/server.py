import os
import json
import base64
from datetime import datetime
from io import BytesIO
import time

from flask import Flask, request, jsonify, render_template_string, send_file
from flask_cors import CORS
import pandas as pd
from reportlab.pdfgen import canvas # type: ignore
from pushbullet import Pushbullet

# -------------------------------------------------------------
# CONFIGURATION
# -------------------------------------------------------------
CSV_FILE = "sensor_log.csv"

TEMP_LIMIT = 24
GAS_LIMIT = 8
HUM_LIMIT = 50   # optional humidity alert threshold

# XOR key (must match ESP8266)
XOR_KEY = b"iotsecure123"

# Pushbullet API KEY (optional)
PUSHBULLET_KEY = "o.TRIuOG3Q9ycocow1n4obWErJxhnu3ESh"
pb = Pushbullet(PUSHBULLET_KEY) if PUSHBULLET_KEY else None

# Latest data for dashboard
latest = {
    "temperature": None,
    "humidity": None,
    "gas": None,
    "time": None
}

# Initialize Flask
app = Flask(__name__)
CORS(app)

# -------------------------------------------------------------
# XOR + Base64 Decryption
# -------------------------------------------------------------
def xor_decrypt_base64(encoded_b64: str) -> str:
    """Decodes Base64, XOR decrypts using XOR_KEY, returns plaintext JSON."""
    
    # fix missing padding
    encoded_b64 = encoded_b64.strip()
    if len(encoded_b64) % 4 != 0:
        encoded_b64 += "=" * (4 - (len(encoded_b64) % 4))

    try:
        raw = base64.b64decode(encoded_b64)
    except Exception as e:
        print("Base64 decode error:", e)
        raise ValueError("Invalid base64")

    out = bytearray(len(raw))
    key = XOR_KEY
    klen = len(key)

    for i in range(len(raw)):
        out[i] = raw[i] ^ key[i % klen]

    try:
        return out.decode("utf-8")
    except:
        print("UTF-8 decode failed:", out)
        raise ValueError("Invalid XOR output")


# -------------------------------------------------------------
# CSV Logger
# -------------------------------------------------------------
def log_csv(row: dict):
    df = pd.DataFrame([row])

    if not os.path.exists(CSV_FILE):
        df.to_csv(CSV_FILE, index=False)
    else:
        df.to_csv(CSV_FILE, mode="a", header=False, index=False)


# -------------------------------------------------------------
# Pushbullet Alerts
# -------------------------------------------------------------
def push_alert(message: str):
    """Sends Pushbullet notification."""
    if not pb:
        print("Pushbullet disabled. Alert:", message)
        return

    try:
        pb.push_note("IoT Alert", message)
        print("Pushbullet sent:", message)
    except Exception as e:
        print("Pushbullet error:", e)
# -------------------------------------------------------------
# Modern Dasboard
# -------------------------------------------------------------
dashboard_html = """
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Secure IoT — Dashboard</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
:root{
  --bg-dark:#0f1724; --card-dark:#0b1220; --muted-dark:#9aa7bd; --accent:#00d9a6;
  --bg-light:#f4f7fb; --card-light:#ffffff; --muted-light:#607089; --accent-light:#0b9f78;
}
html,body{height:100%}
body{
  margin:0; padding:18px; font-family:Inter,system-ui,Segoe UI,Roboto,Arial;
  transition: background 300ms, color 300ms;
}
.container{max-width:1100px;margin:0 auto;}
.header{display:flex;align-items:center;gap:12px;margin-bottom:16px}
.h1{font-size:20px;margin:0}
.small{font-size:13px;color:var(--muted)}
.controls{display:flex;gap:8px;align-items:center;margin-top:8px}
.grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:12px;
}
.card{
  border-radius:12px;padding:14px;box-shadow:0 8px 30px rgba(2,6,23,0.45);
  background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
  transition: transform 200ms, box-shadow 200ms;
  min-height:86px;
}
.card .label{font-size:13px;color:var(--muted);margin-bottom:6px}
.value{font-size:26px;font-weight:700;color:var(--accent)}
.card-row{display:flex;gap:12px;align-items:center}
.meta{font-size:12px;color:var(--muted);margin-top:8px}

.top-controls{display:flex;align-items:center;gap:10px;margin-left:auto}
.btn{
  padding:8px 10px;border-radius:9px;background:transparent;border:1px solid rgba(255,255,255,0.04);
  color:inherit;text-decoration:none;cursor:pointer;font-size:13px;
}

/* alert box */
.alert-box{padding:12px;border-radius:10px;margin-bottom:12px;display:none;color:#fff}
.alert-danger{background:#6f1f1f}

/* pulse animation when alert active */
@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(255,0,0,0.0); transform: translateY(0px); }
  50% { box-shadow: 0 0 18px 6px rgba(0,217,166,0.08); transform: translateY(-2px); }
  100% { box-shadow: 0 0 0 0 rgba(255,0,0,0.0); transform: translateY(0px); }
}
.pulse { animation: pulse 900ms infinite; }

/* small canvas card for gauges */
.gauge-card{display:flex;align-items:center;gap:12px}
.gauge-label{font-size:13px;color:var(--muted);}

/* separate gauge-card-wrapper used for the new layout */
.gauges-row{
  display:flex;
  gap:12px;
  align-items:stretch;
  justify-content:flex-start;
  flex-wrap:wrap;
}

/* each gauge tile */
.gauge-tile{
  flex: 0 0 180px; /* fixed-ish width to preserve gauge sizing on large screens */
  min-width:150px;
  border-radius:10px;
  padding:12px;
  background:var(--card);
  box-shadow:0 6px 18px rgba(2,6,23,0.25);
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:8px;
}

/* ensure canvas doesn't scale too large on big screens */
.gauge-tile canvas {
  width: 120px !important;
  height: 120px !important;
  max-width: 120px;
  max-height: 120px;
  display:block;
}

/* small value under gauge */
.gauge-value { font-size:16px; font-weight:700; color:var(--accent) }

/* dark/light vars (default dark) */
:root[data-theme='dark']{
  --bg:var(--bg-dark); --card:var(--card-dark); --muted:var(--muted-dark); --accent:var(--accent);
}
:root[data-theme='light']{
  --bg:var(--bg-light); --card:var(--card-light); --muted:var(--muted-light); --accent:var(--accent-light);
}
body{background:var(--bg); color: #e6eef8}
[data-theme='light'] body{ color: #0b1b2b }
.card{background:var(--card)} 

/* status pill */
.status-pill{padding:6px 8px;border-radius:999px;font-size:12px;font-weight:600}

/* ------------------------------------------
   MOBILE OPTIMIZATION FOR PHONES
------------------------------------------ */
@media (max-width: 768px) {

  body {
    padding: 10px;
  }

  .header {
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
  }

  .top-controls {
    width: 100%;
    justify-content: flex-start;
    flex-wrap: wrap;
    gap: 6px;
  }

  .btn {
    padding: 6px 10px;
    font-size: 12px;
  }

  .grid {
    grid-template-columns: 1fr;
    gap: 10px;
  }

  .card {
    padding: 12px;
    min-height: auto;
  }

  .value {
    font-size: 22px;
  }

  .meta {
    font-size: 11px;
  }

  .gauge-card {
    flex-direction: column;
    text-align: center;
  }

  .gauge-card canvas {
    width: 90px !important;
    height: 90px !important;
  }

  #trendChart {
    height: 140px !important;
  }

  .card-row {
    flex-direction: row;
  }
}

@media (max-width: 420px) {

  .h1 {
    font-size: 16px;
  }

  .value {
    font-size: 18px;
  }

  .btn {
    width: 100%;
    text-align: center;
  }

  .gauge-card canvas {
    width: 70px !important;
    height: 70px !important;
  }

  #trendChart {
    height: 120px !important;
  }
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1 class="h1">📡 Secure IoT — Dashboard</h1>
    <div class="small">Auto-refresh: 2s</div>

    <div class="top-controls">
      <button id="themeToggle" class="btn">Toggle Theme</button>
      <a class="btn" href="/report" target="_blank">📄 Download Report</a>
    </div>
  </div>

  

  <div id="alertArea" class="alert-box"></div>

  <div class="grid">

    <!-- Temperature Card -->
    <div class="card" id="card-temp">
      <div class="label">Temperature <span id="temp-time" class="small" style="float:right"></span></div>
      <div class="card-row">
        <div>
          <div id="temp" class="value">-- °C</div>
          <div class="meta">Limit: <strong>{{temp_limit}}°C</strong></div>
        </div>
        <div style="margin-left:auto;text-align:right">
          <div id="temp-status" class="status-pill" style="background:transparent;color:inherit">Status</div>
        </div>
      </div>
    </div>

    <!-- Humidity Card -->
    <div class="card" id="card-hum">
      <div class="label">Humidity <span id="hum-time" class="small" style="float:right"></span></div>
      <div class="card-row">
        <div>
          <div id="hum" class="value">-- %</div>
          <div class="meta">Limit: <strong>{{hum_limit}}%</strong></div>
        </div>
        <div style="margin-left:auto;text-align:right">
          <div id="hum-status" class="status-pill" style="background:transparent;color:inherit">Status</div>
        </div>
      </div>
    </div>

    <!-- Gas Card -->
    <div class="card" id="card-gas">
      <div class="label">Gas <span id="gas-time" class="small" style="float:right"></span></div>
      <div class="card-row">
        <div>
          <div id="gas" class="value">--</div>
          <div class="meta">Limit: <strong>{{gas_threshold}}</strong></div>
        </div>
        <div style="margin-left:auto;text-align:right">
          <div id="gas-status" class="status-pill" style="background:transparent;color:inherit">Status</div>
        </div>
      </div>
    </div>

  </div>

  <!-- Gauges as Separate Cards (Option 3 layout) -->
  <div style="margin-top:12px; display:flex; gap:12px; flex-wrap:wrap; align-items:flex-start;">

    <div style="flex:1; min-width:220px; max-width:360px;">
      <div class="label" style="margin-bottom:8px">Gauges</div>

      <div class="gauges-row">
        <!-- Temp gauge tile -->
        <div class="gauge-tile" id="tile-temp">
          <canvas id="gaugeTemp" width="120" height="120"></canvas>
          <div class="gauge-label">Temp</div>
          <div id="gaugeTempVal" class="gauge-value">-- °C</div>
        </div>

        <!-- Humidity gauge tile -->
        <div class="gauge-tile" id="tile-hum">
          <canvas id="gaugeHum" width="120" height="120"></canvas>
          <div class="gauge-label">Humidity</div>
          <div id="gaugeHumVal" class="gauge-value">-- %</div>
        </div>

        <!-- Gas gauge tile -->
        <div class="gauge-tile" id="tile-gas">
          <canvas id="gaugeGas" width="120" height="120"></canvas>
          <div class="gauge-label">Gas</div>
          <div id="gaugeGasVal" class="gauge-value">--</div>
        </div>
      </div>
    </div>

    <!-- Trend chart -->
    <div class="card" style="flex:2; min-width:320px;">
      <div class="label">Recent trends</div>
      <canvas id="trendChart" height="170"></canvas>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const GAS_THRESHOLD = {{gas_threshold}};
const TEMP_LIMIT = {{temp_limit}};
const HUM_LIMIT = {{hum_limit}};

let labels = [], tdata = [], hdata = [], gdata = [];

// Trend chart
const trendCtx = document.getElementById('trendChart').getContext('2d');
const trendChart = new Chart(trendCtx, {
  type: 'line',
  data: {
    labels: labels,
    datasets: [
      { label: 'Temp (°C)', data: tdata, borderColor: '#ff7a7a', tension:0.25, fill:false },
      { label: 'Humidity (%)', data: hdata, borderColor: '#6fb3ff', tension:0.25, fill:false },
      { label: 'Gas', data: gdata, borderColor: '#00d9a6', tension:0.25, fill:false }
    ]
  },
  options: { interaction: { intersect:false, mode:'index' }, plugins:{legend:{position:'bottom'}} }
});

// Make gauges (doughnut)
function makeGauge(canvasId, color) {
  const ctx = document.getElementById(canvasId).getContext('2d');
  return new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels:['value','rest'],
      datasets:[{ data:[0,100], backgroundColor:[color,'rgba(0,0,0,0.12)'], borderWidth:0 }]
    },
    options:{
      circumference:180,
      rotation:270,
      cutout:'80%',        // slightly larger cutout for thinner arc
      plugins:{legend:{display:false}, tooltip:{enabled:false}}
    }
  });
}

const gaugeTemp = makeGauge('gaugeTemp','#ff7a7a');
const gaugeHum  = makeGauge('gaugeHum','#6fb3ff');
const gaugeGas  = makeGauge('gaugeGas','#00d9a6');

// Timestamp formatting
function fmtTime(ts){
  if(!ts) return '--';
  const d=new Date(ts*1000);
  return d.toLocaleString();
}

// Sound alert
let audioCtx;
function beep(duration=200, freq=800, vol=0.12){
  try{
    if(!audioCtx) audioCtx=new (window.AudioContext||window.webkitAudioContext)();
    const o=audioCtx.createOscillator();
    const g=audioCtx.createGain();
    o.type='sine';
    o.frequency.value=freq;
    g.gain.value=vol;
    o.connect(g); g.connect(audioCtx.destination);
    o.start();
    setTimeout(()=>o.stop(), duration);
  }catch(e){}
}

let lastAlertState={gas:false,temp:false,hum:false};

// Poll server
async function poll(){
  try{
    const r=await fetch('/live',{cache:'no-store'});
    const d=await r.json();

    if(!d || d.temperature===null) return;

    const now=Math.floor(Date.now()/1000);

    document.getElementById('temp').textContent=d.temperature+" °C";
    document.getElementById('hum').textContent=d.humidity+" %";
    document.getElementById('gas').textContent=d.gas;

    document.getElementById('temp-time').textContent=fmtTime(d.time);
    document.getElementById('hum-time').textContent=fmtTime(d.time);
    document.getElementById('gas-time').textContent=fmtTime(d.time);

    const age=now-(d.time||0);
    const online=(d.time && age<=12);

    const setStatus=(id,ok)=>{
      const el=document.getElementById(id);
      if(ok){
        el.textContent='Online';
        el.style.background='rgba(11,159,120,0.12)';
        el.style.color='var(--accent)';
      } else {
        el.textContent='Offline';
        el.style.background='rgba(180,40,40,0.12)';
        el.style.color='#ff8a8a';
      }
    };

    setStatus('temp-status', online);
    setStatus('hum-status', online);
    setStatus('gas-status', online);

    // Update chart arrays
    const label=new Date().toLocaleTimeString();
    labels.push(label); 
    tdata.push(d.temperature); 
    hdata.push(d.humidity); 
    gdata.push(d.gas);

    if(labels.length>40){
      labels.shift(); tdata.shift(); hdata.shift(); gdata.shift();
    }

    trendChart.update();

    // Gauges map to 0–100
    function clamp01(v,min,max){
      return Math.max(0,Math.min(100,Math.round((v-min)/(max-min)*100)));
    }

    const tGauge=clamp01(d.temperature,-10,60);
    const hGauge=clamp01(d.humidity,0,100);
    const gGauge=clamp01(d.gas,0,Math.max({{gas_threshold}}, d.gas,300));

    gaugeTemp.data.datasets[0].data=[tGauge,100-tGauge]; gaugeTemp.update();
    gaugeHum.data.datasets[0].data=[hGauge,100-hGauge]; gaugeHum.update();
    gaugeGas.data.datasets[0].data=[gGauge,100-gGauge]; gaugeGas.update();

    document.getElementById('gaugeTempVal').textContent=d.temperature+' °C';
    document.getElementById('gaugeHumVal').textContent=d.humidity+' %';
    document.getElementById('gaugeGasVal').textContent=d.gas;

    const isGasAlert=d.gas>GAS_THRESHOLD;
    const isTempAlert=d.temperature>TEMP_LIMIT;
    const isHumAlert=d.humidity>HUM_LIMIT;

    const alertArea=document.getElementById('alertArea');

    if(isGasAlert||isTempAlert||isHumAlert){
      let html='';
      if(isGasAlert) html+='<div><b>🚨 GAS ALERT</b> Level: '+d.gas+'</div>';
      if(isTempAlert) html+='<div><b>🔥 TEMP ALERT</b> '+d.temperature+' °C</div>';
      if(isHumAlert) html+='<div><b>💧 HUM ALERT</b> '+d.humidity+' %</div>';

      alertArea.style.display='block';
      alertArea.className='alert-box alert-danger pulse';
      alertArea.innerHTML=html;

      if(isGasAlert) document.getElementById('card-gas').classList.add('pulse');
      else document.getElementById('card-gas').classList.remove('pulse');

      if(isTempAlert) document.getElementById('card-temp').classList.add('pulse');
      else document.getElementById('card-temp').classList.remove('pulse');

      if(isHumAlert) document.getElementById('card-hum').classList.add('pulse');
      else document.getElementById('card-hum').classList.remove('pulse');

      if( (isGasAlert && !lastAlertState.gas) ||
          (isTempAlert && !lastAlertState.temp) ||
          (isHumAlert && !lastAlertState.hum) ){
        beep(220,880,0.12);
      }

      lastAlertState={gas:isGasAlert,temp:isTempAlert,hum:isHumAlert};

    } else {
      alertArea.style.display='none';
      alertArea.className='alert-box';
      document.getElementById('card-gas').classList.remove('pulse');
      document.getElementById('card-temp').classList.remove('pulse');
      document.getElementById('card-hum').classList.remove('pulse');
      lastAlertState={gas:false,temp:false,hum:false};
    }

  }catch(e){
    console.error('Poll error', e);
  }
}

// Theme toggle
function applyTheme(theme){
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
}
document.getElementById('themeToggle').addEventListener('click',()=>{
  const cur=document.documentElement.getAttribute('data-theme')||'dark';
  applyTheme(cur==='dark'?'light':'dark');
});
(function(){
  const saved=localStorage.getItem('theme')||'dark';
  applyTheme(saved);
})();

setInterval(poll,2000);
poll();

</script>
</body>
</html>
"""


# -------------------------------------------------------------
# DASHBOARD ROUTES
# -------------------------------------------------------------
@app.route("/")
def dashboard():
    return render_template_string(
        dashboard_html,
        gas_threshold=GAS_LIMIT,
        temp_limit=TEMP_LIMIT,
        hum_limit=HUM_LIMIT
    )


@app.route("/live")
def live():
    # Return the latest dictionary; ensure JSON serializable and include integer time
    resp = {
        "temperature": latest["temperature"],
        "humidity": latest["humidity"],
        "gas": latest["gas"],
        "time": latest["time"]  # unix timestamp (int) or None
    }
    return jsonify(resp)


# -------------------------------------------------------------
# DATA RECEIVER
# -------------------------------------------------------------
@app.route("/data", methods=["POST"])
def receive_data():
    raw_body = request.get_data()
    print("RAW:", raw_body)

    payload = request.get_json(silent=True)
    print("Parsed JSON:", payload)

    if payload is None or "data" not in payload:
        return jsonify({"error": "invalid json"}), 400

    # ------ decrypt ------
    try:
        decrypted_text = xor_decrypt_base64(payload["data"])
        data = json.loads(decrypted_text)
        print("Decrypted payload:", data)
    except Exception as e:
        print("Decrypt error:", e)
        return jsonify({"error": "decrypt failed"}), 400

    # ------ update dashboard ------
    try:
        latest["temperature"] = float(data["temperature"])
        latest["humidity"] = float(data["humidity"])
        latest["gas"] = int(data["gas"])
        latest["time"] = int(datetime.now().timestamp())
    except Exception as e:
        print("Data conversion error:", e)
        return jsonify({"error":"bad data"}), 400

    # ------ log CSV ------
    log_csv({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "temperature": latest["temperature"],
        "humidity": latest["humidity"],
        "gas": latest["gas"],
    })

    # ------ Alerts (server-side Pushbullet) ------
    if latest["gas"] > GAS_LIMIT:
        push_alert(f"⚠ GAS ALERT! Level: {latest['gas']}")

    if latest["temperature"] > TEMP_LIMIT:
        push_alert(f"🔥 TEMP ALERT! {latest['temperature']}°C")

    return jsonify({"status": "ok"}), 200


# -------------------------------------------------------------
# PDF REPORT
# -------------------------------------------------------------
@app.route("/report")
def report():
    if not os.path.exists(CSV_FILE):
        return "<h3>No data recorded yet.</h3>"

    df = pd.read_csv(CSV_FILE).tail(150)

    buffer = BytesIO()
    c = canvas.Canvas(buffer)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, 800, "Secure IoT - Sensor Report")

    c.setFont("Helvetica", 10)
    y = 770

    for _, row in df.iterrows():
        c.drawString(
            40, y,
            f"{row['timestamp']} | T:{row['temperature']}C | H:{row['humidity']}% | Gas:{row['gas']}"
        )
        y -= 14

        if y < 40:
            c.showPage()
            c.setFont("Helvetica", 10)
            y = 800

    c.save()
    buffer.seek(0)

    return send_file(buffer, as_attachment=True,
                     download_name="IoT_Report.pdf",
                     mimetype="application/pdf")

# -------------------------------------------------------------
# RUN SERVER
# -------------------------------------------------------------
if __name__ == "__main__":
    print("Server running at: http://0.0.0.0:5000")
    app.run(host="0.0.0.0", port=5000)
