@echo off
title Secure IoT Server
cd /d "%~dp0"
echo Starting IoT Server using Python Launcher...
C:\Windows\py.exe server.py
pause
